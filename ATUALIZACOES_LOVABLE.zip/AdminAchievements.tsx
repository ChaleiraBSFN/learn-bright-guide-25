import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Save, Plus, Trash2, Map } from 'lucide-react';
import { useAchievementData, TrailNodeDef, availableIcons, IconName } from '@/hooks/useAchievementData';
import { useToast } from '@/hooks/use-toast';

export default function AdminAchievements() {
  const navigate = useNavigate();
  const { nodes, saveNodes } = useAchievementData();
  const [editingNodes, setEditingNodes] = useState<TrailNodeDef[]>(nodes);
  const { toast } = useToast();

  const updateNode = (id: number, field: keyof TrailNodeDef, value: any) => {
    setEditingNodes(prev => prev.map(n => n.id === id ? { ...n, [field]: value } : n));
  };

  const addNode = () => {
    const newId = Math.max(0, ...editingNodes.map(n => n.id)) + 1;
    const newNode: TrailNodeDef = {
      id: newId,
      title: 'Nova Conquista',
      type: 'challenge',
      creditReward: 1,
      iconName: 'Star',
      x: 1500,
      y: 150,
      parents: [],
      objective: 'Descrição do objetivo aqui.',
      timeRequiredMinutes: 0
    };
    setEditingNodes([...editingNodes, newNode]);
  };

  const removeNode = (id: number) => {
    setEditingNodes(prev => prev.filter(n => n.id !== id));
  };

  const handleSave = () => {
    saveNodes(editingNodes);
    toast({ title: 'Sucesso!', description: 'Todas as conquistas foram atualizadas.' });
  };

  return (
    <div className="min-h-screen bg-background p-6 pb-20">
      <div className="max-w-5xl mx-auto space-y-6">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-card p-4 rounded-xl shadow-sm border">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate('/admin')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Map className="h-6 w-6 text-primary" /> Editor da Trilha
              </h1>
              <p className="text-sm text-muted-foreground">Posicione, altere títulos e créditos das conquistas.</p>
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button variant="outline" onClick={addNode}>
              <Plus className="h-4 w-4 mr-2" /> Novo Nó
            </Button>
            <Button onClick={handleSave}>
              <Save className="h-4 w-4 mr-2" /> Salvar Tudo
            </Button>
          </div>
        </div>

        <div className="grid gap-4">
          {editingNodes.map(node => (
            <Card key={node.id} className="overflow-hidden">
              <CardContent className="p-4 sm:p-6 grid gap-4 grid-cols-1 md:grid-cols-12 items-start">
                
                <div className="md:col-span-1 flex flex-col items-center justify-center h-full gap-2">
                  <div className="text-lg font-bold text-muted-foreground">#{node.id}</div>
                  <Button variant="ghost" size="icon" className="text-destructive hover:bg-destructive/10" onClick={() => removeNode(node.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>

                <div className="md:col-span-3 space-y-3">
                  <div>
                    <Label>Título Título</Label>
                    <Input value={node.title} onChange={e => updateNode(node.id, 'title', e.target.value)} />
                  </div>
                  <div>
                    <Label>Tipo Visual</Label>
                    <Select value={node.type} onValueChange={v => updateNode(node.id, 'type', v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="challenge">Desafio</SelectItem>
                        <SelectItem value="quiz">Quiz</SelectItem>
                        <SelectItem value="milestone">Marco (Milestone)</SelectItem>
                        <SelectItem value="reward">Recompensa Épica</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="md:col-span-3 space-y-3">
                  <div>
                    <Label>Ícone</Label>
                    <Select value={node.iconName} onValueChange={v => updateNode(node.id, 'iconName', v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {Object.keys(availableIcons).map(icon => (
                          <SelectItem key={icon} value={icon}>{icon}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Créditos (+)</Label>
                    <Input type="number" value={node.creditReward} onChange={e => updateNode(node.id, 'creditReward', parseInt(e.target.value) || 0)} />
                  </div>
                </div>

                <div className="md:col-span-2 space-y-3">
                  <div>
                    <Label>Posição X (Dir)</Label>
                    <Input type="number" value={node.x} onChange={e => updateNode(node.id, 'x', parseInt(e.target.value) || 0)} />
                  </div>
                  <div>
                    <Label>Posição Y (Baixo)</Label>
                    <Input type="number" value={node.y} onChange={e => updateNode(node.id, 'y', parseInt(e.target.value) || 0)} />
                  </div>
                </div>

                <div className="md:col-span-3 space-y-3">
                  <div>
                    <Label>Pai (ID) para ligar a linha</Label>
                    <Input 
                      placeholder="Ex: 1, 2" 
                      value={node.parents.join(', ')} 
                      onChange={e => {
                        const vals = e.target.value.split(',').map(s => parseInt(s.trim())).filter(n => !isNaN(n));
                        updateNode(node.id, 'parents', vals);
                      }} 
                    />
                  </div>
                  <div>
                    <Label>Objetivo / Mensagem</Label>
                    <Input value={node.objective || ''} placeholder="Texto ao clicar..." onChange={e => updateNode(node.id, 'objective', e.target.value)} />
                  </div>
                  <div>
                    <Label>Tempo Necessário (Em Minutos)</Label>
                    <Input 
                      type="number" 
                      value={node.timeRequiredMinutes || 0} 
                      onChange={e => updateNode(node.id, 'timeRequiredMinutes', parseInt(e.target.value) || 0)} 
                      placeholder="0 = Nenhuma restrição" 
                    />
                    <p className="text-[10px] text-muted-foreground mt-1">Coloque 0 se completar por ação e não por tempo online.</p>
                  </div>
                </div>

              </CardContent>
            </Card>
          ))}
          {editingNodes.length === 0 && (
            <div className="text-center py-10 bg-muted/50 rounded-xl border-2 border-dashed">
              Nenhuma conquista. Clique em "Novo Nó" para começar.
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
