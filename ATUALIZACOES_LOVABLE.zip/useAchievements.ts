import { useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useCredits } from '@/hooks/useCredits';
import { useToast } from '@/hooks/use-toast';
import { useAchievementData } from '@/hooks/useAchievementData';

export const useAchievements = () => {
  const { user } = useAuth();
  const { addCredits } = useCredits();
  const { toast } = useToast();
  const { nodes } = useAchievementData();

  const checkAndUnlock = useCallback(async (actionType?: string, explicitNodeId?: number) => {
    if (!user) return;

    let targetNodeId: number | null = null;
    
    if (actionType === 'generate_study') targetNodeId = 1;
    else if (actionType === 'generate_quiz') targetNodeId = 2;
    else if (explicitNodeId) targetNodeId = explicitNodeId;

    if (!targetNodeId) return;

    const nodeConf = nodes.find(n => n.id === targetNodeId);
    if (!nodeConf) return;

    const nodeContext = { title: nodeConf.title, reward: nodeConf.creditReward };

    try {
      const { error } = await (supabase.from as any)('user_achievements')
        .insert({ user_id: user.id, achievement_id: targetNodeId });

      if (error && error.code !== '23505') throw error;
      
      // If no error, it means it was inserted successfully
      if (!error) {
        await addCredits(nodeContext.reward);
        toast({ 
          title: "Conquista Desbloqueada! 🏆", 
          description: `Você completou "${nodeContext.title}" e ganhou +${nodeContext.reward} créditos!` 
        });
      }
    } catch (err) {
      // Fallback local
      const key = `achievements_v2_${user.id}`;
      const stored = JSON.parse(localStorage.getItem(key) || '[]');
      if (!stored.includes(targetNodeId)) {
        stored.push(targetNodeId);
        localStorage.setItem(key, JSON.stringify(stored));
        await addCredits(nodeContext.reward);
        toast({ 
          title: "Conquista Desbloqueada! 🏆", 
          description: `Você completou "${nodeContext.title}" e ganhou +${nodeContext.reward} créditos!` 
        });
      }
    }
  }, [user, addCredits, toast, nodes]);

  const checkAndUnlockTime = useCallback(async (totalMinutes: number) => {
    if (!user) return;
    const timeNodes = nodes.filter(n => n.timeRequiredMinutes && n.timeRequiredMinutes > 0 && n.timeRequiredMinutes <= totalMinutes);
    
    if (timeNodes.length === 0) return;
    
    const key = `achievements_v2_${user.id}`;
    const stored = JSON.parse(localStorage.getItem(key) || '[]');
    
    for (const node of timeNodes) {
      if (!stored.includes(node.id)) {
        await checkAndUnlock(undefined, node.id);
      }
    }
  }, [user, nodes, checkAndUnlock]);

  return { checkAndUnlock, checkAndUnlockTime };
};
